#include "PortLatency.h"

PortLatency::PortLatency(QString portName)
    : portName(portName),
    isSwitched(false)
{

}
